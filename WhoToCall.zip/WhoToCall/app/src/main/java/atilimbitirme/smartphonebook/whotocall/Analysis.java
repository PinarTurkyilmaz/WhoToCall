package atilimbitirme.smartphonebook.whotocall;

import android.telephony.PhoneNumberUtils;

import java.util.ArrayList;

/**
 * This class is used when analysing call and SMS history. It provides methods such as incrementing
 * call count of a contact. Created on 31.03.2016.
 */
public class Analysis
{

    private ArrayList<item> list = new ArrayList<>();

    /**
     * @param phoneNumber Phone number as String whose counts be set
     * @param counts      Two dimensional int array
     */
    public void setCountsOfPhoneNumber(String phoneNumber, int[][] counts)
    {
        for (item i : list)
        {
            if (comparePhoneNumbers(i.phoneNumber, phoneNumber))
            {
                i.counts = counts;
                break;
            }
        }
    }

    /**
     * @param phoneNumber Phone number as String whose counts be incremented
     * @param counts      Two dimensional int array
     */
    public void combineCountsOfPhoneNumber(String phoneNumber, int[][] counts)
    {
        for (item it : list)
        {
            if (comparePhoneNumbers(it.phoneNumber, phoneNumber))
            {
                for (int i = 0; i < 8; i++)
                {
                    for (int j = 0; j < 24; j++)
                    {
                        it.counts[i][j] += counts[i][j];
                    }
                }
                break;
            }
        }
    }

    /**
     * @param phoneNumber Phone number as String to add to analysis list
     * @return Returns true if phone number is new and added to list, false otherwise.
     */
    public boolean addIfNotExist(String phoneNumber)
    {
        boolean bFound = false;
        for (item i : list)
        {
            if (comparePhoneNumbers(i.phoneNumber, phoneNumber))
            {
                bFound = true;
                break;
            }
        }
        if (!bFound)
            list.add(new item(phoneNumber));
        return !bFound;
    }

    public void increment(String phoneNumber, int iDayOfWeek, int iHourOfDay)
    {
        for (item i : list)
        {
            if (comparePhoneNumbers(i.phoneNumber, phoneNumber))
            {
                i.counts[iDayOfWeek][iHourOfDay] += 1;
                break;
            }
        }
    }

    public ArrayList<item> getList()
    {
        return this.list;
    }

    private boolean comparePhoneNumbers(String pn1, String pn2)
    {
        boolean isEqual;
        isEqual = PhoneNumberUtils.compare(pn1, pn2);
        return isEqual;
    }

    public class item
    {
        // First dimension: Day of Week
        // Second dimension: Hour of Day
        public int[][] counts = new int[8][24];
        public String phoneNumber;

        public item(String phoneNumber)
        {
            this.phoneNumber = phoneNumber;
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 24; j++)
                {
                    counts[i][j] = 0;
                }
            }
        }
    }
}
