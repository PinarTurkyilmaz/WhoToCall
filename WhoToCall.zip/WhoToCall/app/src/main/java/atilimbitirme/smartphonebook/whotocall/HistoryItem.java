package atilimbitirme.smartphonebook.whotocall;

import java.util.Date;

/**
 * This class is used as a helper when analysing call and SMS history. Every object of this class
 * represents a row in a history table. Created on 31.03.2016.
 */
public class HistoryItem
{
    public String phoneNumber, datetime;

    public HistoryItem(String datetime, String phoneNumber)
    {
        this.datetime = datetime;
        this.phoneNumber = phoneNumber;
    }

    public Date getDate()
    {
        return new Date(Long.valueOf(this.datetime));
    }
}
