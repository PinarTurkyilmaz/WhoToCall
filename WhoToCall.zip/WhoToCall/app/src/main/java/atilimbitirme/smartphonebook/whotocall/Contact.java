package atilimbitirme.smartphonebook.whotocall;

/**
 * This is an entity class. Objects of this class represent contacts of the phone. Created on
 * 10.04.2016.
 */
public class Contact
{
    private String fullName;
    private String phoneNumber;
    private boolean blocked;
    private int notificationDayOfWeek;
    private int notificationHourOfDay;

    public Contact(boolean blocked, String fullName, int notificationDayOfWeek,
                   int notificationHourOfDay, String phoneNumber)
    {
        this.blocked = blocked;
        this.fullName = fullName;
        this.notificationDayOfWeek = notificationDayOfWeek;
        this.notificationHourOfDay = notificationHourOfDay;
        this.phoneNumber = phoneNumber;
    }

    public Contact(boolean blocked, String fullName, String phoneNumber)
    {
        this.blocked = blocked;
        this.fullName = fullName;
        this.phoneNumber = phoneNumber;
    }

    public Contact(String fullName, String phoneNumber)
    {
        this.fullName = fullName;
        this.phoneNumber = phoneNumber;
    }

    public boolean isBlocked()
    {
        return blocked;
    }

    public void setBlocked(boolean blocked)
    {
        this.blocked = blocked;
    }

    public String getPhoneNumber()
    {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber)
    {
        this.phoneNumber = phoneNumber;
    }

    public String getFullName()
    {
        return fullName;
    }

    public void setFullName(String fullName)
    {
        this.fullName = fullName;
    }

    public int getNotificationDayOfWeek()
    {
        return notificationDayOfWeek;
    }

    public int getNotificationHourOfDay()
    {
        return notificationHourOfDay;
    }
}
