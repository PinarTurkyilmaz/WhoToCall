package atilimbitirme.smartphonebook.whotocall;

import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.RelativeLayout;

import java.util.ArrayList;


/**
 * List of blocked contacts is shown in this activity. This activity is started from {@link
 * MainActivity} by clicking "Show blocked contacts" button.
 */
public class BlockedContactsActivity extends AppCompatActivity
{
    private static MainController mainController;
    private Toolbar toolbar;
    private ListView blockedListView;
    private ArrayAdapter<String> listViewAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_blocked_contacts);
        toolbar = (Toolbar) findViewById(R.id.blocked_contacts_activity_toolbar);
        setSupportActionBar(toolbar);

        // Get a support ActionBar corresponding to this toolbar
        ActionBar ab = getSupportActionBar();

        // Enable the Up button
        if (ab != null)
        {
            ab.setDisplayHomeAsUpEnabled(true);
        }

        blockedListView = (ListView) findViewById(R.id.blocked_list_view);
        mainController = MainController.getInstance(this);
        mainController.getBlockedContacts();
    }

    public void showBlockedContactsList(ArrayList<Contact> contacts)
    {
        ArrayList<String> contactsAsString = new ArrayList<>();

        for (Contact c : contacts)
        {
            contactsAsString.add(c.getFullName());
        }

        if (listViewAdapter != null)
        {
            listViewAdapter.clear();
            listViewAdapter.addAll(contactsAsString);
            listViewAdapter.notifyDataSetChanged();
        }
        else
        {
            listViewAdapter = new ArrayAdapter<>(this, R.layout.blocked_list_item,
                    R.id.blocked_list_item_textview, contactsAsString);

            if (blockedListView != null)
                blockedListView.setAdapter(listViewAdapter);
        }
    }

    public void unblockContact(View view)
    {
        RelativeLayout vwParentRow = (RelativeLayout) view.getParent();
        ListView lvParent = (ListView) vwParentRow.getParent();
        int index = lvParent.getPositionForView(vwParentRow);

        mainController.unblockContact(index);
        mainController.getBlockedContacts();
    }
}
