package atilimbitirme.smartphonebook.whotocall;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * This class provides access to the local SQLite database. Created on 21.03.2016.
 */
public class CallSmsHistoryDbHelper extends SQLiteOpenHelper
{
    // If you change the database schema, you must increment the database version.
    public static final int DATABASE_VERSION = 1;
    public static final String DATABASE_NAME = "CallSmsHistory.db";
    private static final String SQL_CREATE_CALL_TABLE_ENTRIES =
            "CREATE TABLE " + CallSmsHistoryContract.CallEntry.TABLE_NAME + " (" +
                    CallSmsHistoryContract.CallEntry.COLUMN_NAME_PHONE_NUMBER + " TEXT, " +
                    CallSmsHistoryContract.CallEntry.COLUMN_NAME_DATETIME + " TEXT, " +
                    CallSmsHistoryContract.CallEntry.COLUMN_NAME_DURATION + "TEXT, " +
                    "PRIMARY KEY (" +
                    CallSmsHistoryContract.CallEntry.COLUMN_NAME_PHONE_NUMBER + ", " +
                    CallSmsHistoryContract.CallEntry.COLUMN_NAME_DATETIME +
                    ")" + ")";
    private static final String SQL_CREATE_SMS_TABLE_ENTRIES =
            "CREATE TABLE " + CallSmsHistoryContract.SMSEntry.TABLE_NAME + " (" +
                    CallSmsHistoryContract.SMSEntry.COLUMN_NAME_PHONE_NUMBER + " TEXT, " +
                    CallSmsHistoryContract.SMSEntry.COLUMN_NAME_DATETIME + " TEXT, " +
                    "PRIMARY KEY (" +
                    CallSmsHistoryContract.SMSEntry.COLUMN_NAME_PHONE_NUMBER + ", " +
                    CallSmsHistoryContract.SMSEntry.COLUMN_NAME_DATETIME +
                    ")" + ")";
    private static final String SQL_CREATE_COUNT_TABLE_ENTRIES =
            "CREATE TABLE " + CallSmsHistoryContract.CountEntry.TABLE_NAME + " (" +
                    CallSmsHistoryContract.CountEntry.COLUMN_NAME_PHONE_NUMBER + " TEXT, " +
                    CallSmsHistoryContract.CountEntry.COLUMN_NAME_DAYOFWEEK + " TEXT, " +
                    CallSmsHistoryContract.CountEntry.COLUMN_NAME_HOUROFDAY + " TEXT, " +
                    CallSmsHistoryContract.CountEntry.COLUMN_NAME_COUNT + " TEXT, " +
                    "PRIMARY KEY (" +
                    CallSmsHistoryContract.CountEntry.COLUMN_NAME_PHONE_NUMBER + ", " +
                    CallSmsHistoryContract.CountEntry.COLUMN_NAME_DAYOFWEEK + ", " +
                    CallSmsHistoryContract.CountEntry.COLUMN_NAME_HOUROFDAY +
                    ")" + ")";
    private static final String SQL_CREATE_ISBLOCKED_TABLE_ENTRIES =
            "CREATE TABLE " + CallSmsHistoryContract.isBlockedEntry.TABLE_NAME + " (" +
                    CallSmsHistoryContract.isBlockedEntry.COLUMN_NAME_PHONE_NUMBER + " TEXT, " +
                    CallSmsHistoryContract.isBlockedEntry.COLUMN_NAME_BLOCKED + " TEXT, " +
                    "PRIMARY KEY (" +
                    CallSmsHistoryContract.isBlockedEntry.COLUMN_NAME_PHONE_NUMBER +
                    ")" + ")";
    private static final String SQL_CREATE_CALL_RESULT_TABLE_ENTRIES =
            "CREATE TABLE " + CallSmsHistoryContract.CallResultEntry.TABLE_NAME + " (" +
                    CallSmsHistoryContract.CallResultEntry.COLUMN_NAME_PHONE_NUMBER + " TEXT, " +
                    CallSmsHistoryContract.CallResultEntry.COLUMN_NAME_DAYOFWEEK + " TEXT, " +
                    CallSmsHistoryContract.CallResultEntry.COLUMN_NAME_HOUROFDAY + " TEXT, " +
                    CallSmsHistoryContract.CallResultEntry.COLUMN_NAME_RATE + " TEXT, " +
                    "PRIMARY KEY (" +
                    CallSmsHistoryContract.CallResultEntry.COLUMN_NAME_PHONE_NUMBER + ", " +
                    CallSmsHistoryContract.CallResultEntry.COLUMN_NAME_DAYOFWEEK + ", " +
                    CallSmsHistoryContract.CallResultEntry.COLUMN_NAME_HOUROFDAY +
                    ")" + ")";
    private static final String SQL_CREATE_SMS_RESULT_TABLE_ENTRIES =
            "CREATE TABLE " + CallSmsHistoryContract.SmsResultEntry.TABLE_NAME + " (" +
                    CallSmsHistoryContract.SmsResultEntry.COLUMN_NAME_PHONE_NUMBER + " TEXT, " +
                    CallSmsHistoryContract.SmsResultEntry.COLUMN_NAME_DAYOFWEEK + " TEXT, " +
                    CallSmsHistoryContract.SmsResultEntry.COLUMN_NAME_HOUROFDAY + " TEXT, " +
                    CallSmsHistoryContract.SmsResultEntry.COLUMN_NAME_RATE + " TEXT, " +
                    "PRIMARY KEY (" +
                    CallSmsHistoryContract.SmsResultEntry.COLUMN_NAME_PHONE_NUMBER + ", " +
                    CallSmsHistoryContract.SmsResultEntry.COLUMN_NAME_DAYOFWEEK + ", " +
                    CallSmsHistoryContract.SmsResultEntry.COLUMN_NAME_HOUROFDAY +
                    ")" + ")";
    private static final String SQL_CREATE_FINAL_RESULT_TABLE_ENTRIES =
            "CREATE TABLE " + CallSmsHistoryContract.FinalResultEntry.TABLE_NAME + " (" +
                    CallSmsHistoryContract.FinalResultEntry.COLUMN_NAME_PHONE_NUMBER + " TEXT, " +
                    CallSmsHistoryContract.FinalResultEntry.COLUMN_NAME_DAYOFWEEK + " TEXT, " +
                    CallSmsHistoryContract.FinalResultEntry.COLUMN_NAME_HOUROFDAY + " TEXT, " +
                    CallSmsHistoryContract.FinalResultEntry.COLUMN_NAME_RATE + " TEXT, " +
                    "PRIMARY KEY (" +
                    CallSmsHistoryContract.FinalResultEntry.COLUMN_NAME_PHONE_NUMBER + ", " +
                    CallSmsHistoryContract.FinalResultEntry.COLUMN_NAME_DAYOFWEEK + ", " +
                    CallSmsHistoryContract.FinalResultEntry.COLUMN_NAME_HOUROFDAY +
                    ")" + ")";
    private static final String SQL_DELETE_CALL_TABLE_ENTRIES =
            "DROP TABLE IF EXISTS " + CallSmsHistoryContract.CallEntry.TABLE_NAME;
    private static final String SQL_DELETE_SMS_TABLE_ENTRIES =
            "DROP TABLE IF EXISTS " + CallSmsHistoryContract.SMSEntry.TABLE_NAME;
    private static final String SQL_DELETE_COUNT_TABLE_ENTRIES =
            "DROP TABLE IF EXISTS " + CallSmsHistoryContract.CountEntry.TABLE_NAME;
    private static final String SQL_DELETE_ISBLOCKED_TABLE_ENTRIES =
            "DROP TABLE IF EXISTS " + CallSmsHistoryContract.isBlockedEntry.TABLE_NAME;
    private static final String SQL_DELETE_CALL_RESULT_TABLE_ENTRIES =
            "DROP TABLE IF EXISTS " + CallSmsHistoryContract.CallResultEntry.TABLE_NAME;
    private static final String SQL_DELETE_SMS_RESULT_TABLE_ENTRIES =
            "DROP TABLE IF EXISTS " + CallSmsHistoryContract.SmsResultEntry.TABLE_NAME;
    private static final String SQL_DELETE_FINAL_RESULT_TABLE_ENTRIES =
            "DROP TABLE IF EXISTS " + CallSmsHistoryContract.FinalResultEntry.TABLE_NAME;

    public CallSmsHistoryDbHelper(Context context)
    {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db)
    {
        db.execSQL(SQL_CREATE_CALL_TABLE_ENTRIES);
        db.execSQL(SQL_CREATE_SMS_TABLE_ENTRIES);
        db.execSQL(SQL_CREATE_COUNT_TABLE_ENTRIES);
        db.execSQL(SQL_CREATE_ISBLOCKED_TABLE_ENTRIES);
        db.execSQL(SQL_CREATE_CALL_RESULT_TABLE_ENTRIES);
        db.execSQL(SQL_CREATE_SMS_RESULT_TABLE_ENTRIES);
        db.execSQL(SQL_CREATE_FINAL_RESULT_TABLE_ENTRIES);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
    {
    }

    public void resetResultTable(SQLiteDatabase db)
    {
        db.execSQL(SQL_DELETE_COUNT_TABLE_ENTRIES);
        db.execSQL(SQL_CREATE_COUNT_TABLE_ENTRIES);
    }

    public void resetSmsResultTable(SQLiteDatabase db)
    {
        db.execSQL(SQL_DELETE_SMS_RESULT_TABLE_ENTRIES);
        db.execSQL(SQL_CREATE_SMS_RESULT_TABLE_ENTRIES);
    }

    public void resetCallResultTable(SQLiteDatabase db)
    {
        db.execSQL(SQL_DELETE_CALL_RESULT_TABLE_ENTRIES);
        db.execSQL(SQL_CREATE_CALL_RESULT_TABLE_ENTRIES);
    }

    public void resetFinalResultTable(SQLiteDatabase db)
    {
        db.execSQL(SQL_DELETE_FINAL_RESULT_TABLE_ENTRIES);
        db.execSQL(SQL_CREATE_FINAL_RESULT_TABLE_ENTRIES);
    }
}
