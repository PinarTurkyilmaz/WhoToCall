package atilimbitirme.smartphonebook.whotocall;

import android.Manifest;
import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.Process;
import android.provider.CallLog;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.NotificationCompat;
import android.util.Log;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import atilimbitirme.smartphonebook.whotocall.phonelogaccessors.CallLogAccessor;

/**
 * This class is a Service for refresh list process. By this, refresh process can be run on
 * background even if the application is killed. Created on 30.04.2016.
 */
public class RefreshService extends Service
{
    static SQLiteDatabase db;
    static NotificationManager mNotifyManager;
    static NotificationCompat.Builder mBuilder;
    static private MainController mainController;
    static private int id = 1;
    private Looper mServiceLooper;
    private ServiceHandler mServiceHandler;

    public RefreshService()
    {
        super();
    }


    public RefreshService(MainController mainController, NotificationManager mNotifyManager,
                          NotificationCompat.Builder mBuilder, int id)
    {
        super();
        RefreshService.mNotifyManager = mNotifyManager;
        RefreshService.mBuilder = mBuilder;
        RefreshService.mainController = mainController;
        RefreshService.id = id;
    }

    @Override
    public void onCreate()
    {
        // Start up the thread running the service.  Note that we create a
        // separate thread because the service normally runs in the process's
        // main thread, which we don't want to block.  We also make it
        // background priority so CPU-intensive work will not disrupt our UI.
        HandlerThread thread =
                new HandlerThread("ServiceStartArguments", Process.THREAD_PRIORITY_BACKGROUND);
        thread.start();

        // Get the HandlerThread's Looper and use it for our Handler
        mServiceLooper = thread.getLooper();
        mServiceHandler = new ServiceHandler(mServiceLooper);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId)
    {
        Toast.makeText(this, "You can check the progress from the notification", Toast.LENGTH_LONG)
                .show();
        Intent notificationIntent = new Intent(getApplicationContext(), MainActivity.class);
        PendingIntent pendingIntent =
                PendingIntent.getActivity(getApplicationContext(), 0, notificationIntent, 0);
        NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(this);
        mBuilder.setContentTitle("List Refresh")
                .setContentText("New records are being collected and analysed").
                setSmallIcon(R.mipmap.ic_launcher).setContentIntent(pendingIntent);
        Notification notification = mBuilder.build();
        startForeground(1, notification);
        // For each start request, send a message to start a job and deliver the
        // start ID so we know which request we're stopping when we finish the job
        Message msg = mServiceHandler.obtainMessage();
        msg.arg1 = startId;
        mServiceHandler.sendMessage(msg);

        // If we get killed, after returning from here, restart
        return START_STICKY;
    }

    @Override
    public void onDestroy()
    {
        mBuilder.setContentText("Refresh complete")
                // Removes the progress bar
                .setProgress(0, 0, false);
        mNotifyManager.notify(id, mBuilder.build());
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent)
    {
        return null;
    }

    private void updateCallHistory()
    {
        SQLiteDatabase db = mainController.callSmsHistoryDbHelper.getWritableDatabase();

        if (ActivityCompat.checkSelfPermission(mainController.mainActivity,
                Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED)
        {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        Cursor managedCursor = mainController.mainActivity.getContentResolver()
                .query(CallLog.Calls.CONTENT_URI, null, null, null, null);
        int number, type, date;
        if (managedCursor != null)
        {
            number = managedCursor.getColumnIndex(CallLog.Calls.NUMBER);
            type = managedCursor.getColumnIndex(CallLog.Calls.TYPE);
            date = managedCursor.getColumnIndex(CallLog.Calls.DATE);
            int total = managedCursor.getCount(),
                    processedCount = 0;
            while (managedCursor.moveToNext())
            {
                String phNumber = managedCursor.getString(number);
                String callType = managedCursor.getString(type);
                String callDate = managedCursor.getString(date);
                String duration = managedCursor
                        .getString(managedCursor.getColumnIndex(CallLog.Calls.DURATION));
                int dircode = Integer.parseInt(callType);
                switch (dircode)
                {
                    case CallLog.Calls.MISSED_TYPE:
                    case CallLog.Calls.OUTGOING_TYPE:
                        // Create a new map of values, where column names are the keys
                        ContentValues values = new ContentValues();
                        values.put(CallSmsHistoryContract.CallEntry.COLUMN_NAME_PHONE_NUMBER,
                                phNumber);
                        values.put(CallSmsHistoryContract.CallEntry.COLUMN_NAME_DATETIME, callDate);
                        values.put(CallSmsHistoryContract.CallEntry.COLUMN_NAME_DURATION, duration);
                        // Insert the new row, returning the primary key value of the new row
                        db.insert(CallSmsHistoryContract.CallEntry.TABLE_NAME, null, values);
                        break;
                }
                mBuilder.setProgress(total, processedCount++, false);
                mNotifyManager.notify(id, mBuilder.build());
            }
            managedCursor.close();
        }
    }

    private void updateSmsHistory()
    {
        Calendar calendar = Calendar.getInstance();

        SQLiteDatabase db = mainController.callSmsHistoryDbHelper.getWritableDatabase();

        if (ActivityCompat.checkSelfPermission(mainController.mainActivity,
                Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED)
        {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }

        calendar.add(Calendar.YEAR, -1);
        Date oneyearbefore = calendar.getTime();

        Cursor c = mainController.mainActivity.getContentResolver()
                .query(Uri.parse("content://sms/sent"), null, null, null, null);

        if (c != null)
        {
            int total = c.getCount(), processedCount = 0;

            if (c.moveToFirst() && !c.isNull(c.getColumnIndex("date")) &&
                    !c.isNull(c.getColumnIndex("address")))
            {
                do
                {
                    String phoneNumber = c.getString(c.getColumnIndex("address"));
                    String date = c.getString(c.getColumnIndex("date"));
                    Date tempdate = new Date(Long.valueOf(date));
                    if (tempdate.before(oneyearbefore))
                    {
                        mBuilder.setProgress(total, processedCount++, false);
                        mNotifyManager.notify(id, mBuilder.build());
                        continue;
                    }
                    ContentValues insertValues = new ContentValues();
                    insertValues.put(CallSmsHistoryContract.SMSEntry.COLUMN_NAME_PHONE_NUMBER,
                            phoneNumber);
                    insertValues.put(CallSmsHistoryContract.SMSEntry.COLUMN_NAME_DATETIME, date);
                    db.insert(CallSmsHistoryContract.SMSEntry.TABLE_NAME, null, insertValues);
                    mBuilder.setProgress(total, processedCount++, false);
                    mNotifyManager.notify(id, mBuilder.build());
                } while (c.moveToNext());
            }
            c.close();
        }
    }

    /**
     * Returns the content of SMS History Table {@link atilimbitirme.smartphonebook.whotocall.CallSmsHistoryContract.SMSEntry}
     * as an ArrayList.
     */
    private ArrayList<HistoryItem> getSmsHistoryArrayList()
    {
        ArrayList<HistoryItem> resultArrayList = new ArrayList<>();
        SQLiteDatabase db = mainController.callSmsHistoryDbHelper.getReadableDatabase();

        String sortOrder = CallSmsHistoryContract.SMSEntry.COLUMN_NAME_DATETIME + " DESC";

        Cursor c =
                db.query(CallSmsHistoryContract.SMSEntry.TABLE_NAME, null, null, null, null, null,
                        sortOrder);

        int phoneNumberColumnIndex =
                c.getColumnIndex(CallSmsHistoryContract.SMSEntry.COLUMN_NAME_PHONE_NUMBER);
        int dateTimeColumnIndex =
                c.getColumnIndex(CallSmsHistoryContract.SMSEntry.COLUMN_NAME_DATETIME);

        String phoneNumber, datetime;

        int total = c.getCount(), processedCount = 0;

        c.moveToFirst();
        if (c.getCount() > 0)
            do
            {
                phoneNumber = c.getString(phoneNumberColumnIndex);
                datetime = c.getString(dateTimeColumnIndex);
                resultArrayList.add(new HistoryItem(datetime, phoneNumber));
                mBuilder.setProgress(total, processedCount++, false);
                mNotifyManager.notify(id, mBuilder.build());
            } while (c.moveToNext());

        c.close();

        return resultArrayList;
    }

    private ArrayList<HistoryItem> getCallHistoryArrayList()
    {
        String phoneNumber, datetime;
        SQLiteDatabase db = mainController.callSmsHistoryDbHelper.getReadableDatabase();

        String sortOrder = CallSmsHistoryContract.CallEntry.COLUMN_NAME_DATETIME + " DESC";

        Cursor c = db.query(CallSmsHistoryContract.CallEntry.TABLE_NAME,  // The table to query
                null,                               // The columns to return
                null,                                // The columns for the WHERE clause
                null,                            // The values for the WHERE clause
                null,                                     // don't group the rows
                null,                                     // don't filter by row groups
                sortOrder                                 // The sort order
        );

        ArrayList<HistoryItem> resultArrayList = new ArrayList<>();
        int phoneNumberColumnIndex =
                c.getColumnIndex(CallSmsHistoryContract.CallEntry.COLUMN_NAME_PHONE_NUMBER);
        int dateTimeColumnIndex =
                c.getColumnIndex(CallSmsHistoryContract.CallEntry.COLUMN_NAME_DATETIME);

        int total = c.getCount(),
                processedCount = 0;
        c.moveToFirst();
        if (c.getCount() > 0)
            do
            {
                phoneNumber = c.getString(phoneNumberColumnIndex);
                datetime = c.getString(dateTimeColumnIndex);
                resultArrayList.add(new HistoryItem(datetime, phoneNumber));
                mBuilder.setProgress(total, processedCount++, false);
                mNotifyManager.notify(id, mBuilder.build());
            } while (c.moveToNext());

        c.close();
        return resultArrayList;
    }

    private void setNotificationTimings()
    {
        // Set call notification timings
        ArrayList<Contact> contacts = new ArrayList<>();
        SQLiteDatabase db = mainController.callSmsHistoryDbHelper.getReadableDatabase();
        Cursor c = db.rawQuery("SELECT " +
                CallSmsHistoryContract.CallResultEntry.COLUMN_NAME_PHONE_NUMBER + ", " +
                CallSmsHistoryContract.CallResultEntry.COLUMN_NAME_DAYOFWEEK + ", " +
                CallSmsHistoryContract.CallResultEntry.COLUMN_NAME_HOUROFDAY + ", " +
                CallSmsHistoryContract.CallResultEntry.COLUMN_NAME_RATE +
                ", MAX(" +
                CallSmsHistoryContract.CallResultEntry.COLUMN_NAME_RATE + ") FROM " +
                CallSmsHistoryContract.CallResultEntry.TABLE_NAME + " GROUP BY " +
                CallSmsHistoryContract.CallResultEntry.COLUMN_NAME_PHONE_NUMBER, null);

        c.moveToFirst();
        if (c.getCount() > 0)
            do
            {
                String phoneNumber = c.getString(c.getColumnIndex(
                        CallSmsHistoryContract.CallResultEntry.COLUMN_NAME_PHONE_NUMBER));
                String name =
                        CallLogAccessor.getContactName(mainController.mainActivity, phoneNumber);
                String count = c.getString(
                        c.getColumnIndex(CallSmsHistoryContract.CallResultEntry.COLUMN_NAME_RATE));
                int dayofweek = c.getInt(c.getColumnIndex(
                        CallSmsHistoryContract.CallResultEntry.COLUMN_NAME_DAYOFWEEK));
                int hourofday = c.getInt(c.getColumnIndex(
                        CallSmsHistoryContract.CallResultEntry.COLUMN_NAME_HOUROFDAY));
                contacts.add(new Contact(false, name, dayofweek, hourofday, phoneNumber));
            } while (c.moveToNext());
        c.close();

        // Get the alarm manager service
        AlarmManager alarmManager =
                (AlarmManager) mainController.mainActivity.getSystemService(Context.ALARM_SERVICE);
        ArrayList<PendingIntent> pendingIntents = new ArrayList<>();
        int count = 0;
        for (Contact contact : contacts)
        {
            Calendar calendar = Calendar.getInstance();
            calendar.set(Calendar.DAY_OF_WEEK, contact.getNotificationDayOfWeek());
            calendar.set(Calendar.HOUR_OF_DAY, contact.getNotificationHourOfDay());
            calendar.set(Calendar.MINUTE, 0);

            // Create an intent that will be wrapped in PendingIntent
            Intent intent = new Intent(mainController.mainActivity, AlarmReceiver.class);
            intent.putExtra("CONTACT_NAME", CallLogAccessor
                    .getContactName(mainController.mainActivity, contact.getPhoneNumber()));
            intent.putExtra("NOTIFICATION_ID", count);
            intent.putExtra("TYPE", "CALL");
            intent.putExtra("PHONE_NUMBER", contact.getPhoneNumber());

            // Create the pending intent and wrap our intent
            PendingIntent pendingIntent =
                    PendingIntent.getBroadcast(mainController.mainActivity, count, intent, 0);

            // Testing notifications
            //            alarmManager.cancel(pendingIntent);
            //            alarmManager
            //                    .set(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + 5000, pendingIntent);
            //            break;

            if (System.currentTimeMillis() > calendar.getTimeInMillis())
            {
                alarmManager.setRepeating(AlarmManager.RTC_WAKEUP,
                        calendar.getTimeInMillis() + AlarmManager.INTERVAL_DAY * 7,
                        AlarmManager.INTERVAL_DAY * 7, pendingIntent);
                Log.d("Alarm", "Alarm time: " +
                        new Date(calendar.getTimeInMillis() + AlarmManager.INTERVAL_DAY * 7)
                                .toString());
            }
            else
            {
                alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(),
                        AlarmManager.INTERVAL_DAY * 7, pendingIntent);

                Log.d("Alarm", "Alarm time: " + new Date(calendar.getTimeInMillis()).toString());
            }
            pendingIntents.add(pendingIntent);
            count++;
        }
        // End of setting call notification timings

        // Set SMS notification timings
        contacts.clear();
        c = db.rawQuery("SELECT " +
                CallSmsHistoryContract.SmsResultEntry.COLUMN_NAME_PHONE_NUMBER + ", " +
                CallSmsHistoryContract.SmsResultEntry.COLUMN_NAME_DAYOFWEEK + ", " +
                CallSmsHistoryContract.SmsResultEntry.COLUMN_NAME_HOUROFDAY + ", " +
                CallSmsHistoryContract.SmsResultEntry.COLUMN_NAME_RATE +
                ", MAX(" +
                CallSmsHistoryContract.SmsResultEntry.COLUMN_NAME_RATE + ") FROM " +
                CallSmsHistoryContract.SmsResultEntry.TABLE_NAME + " GROUP BY " +
                CallSmsHistoryContract.SmsResultEntry.COLUMN_NAME_PHONE_NUMBER, null);

        c.moveToFirst();
        if (c.getCount() > 0)
            do
            {
                String phoneNumber = c.getString(c.getColumnIndex(
                        CallSmsHistoryContract.SmsResultEntry.COLUMN_NAME_PHONE_NUMBER));
                String name =
                        CallLogAccessor.getContactName(mainController.mainActivity, phoneNumber);
                int dayofweek = c.getInt(c.getColumnIndex(
                        CallSmsHistoryContract.SmsResultEntry.COLUMN_NAME_DAYOFWEEK));
                int hourofday = c.getInt(c.getColumnIndex(
                        CallSmsHistoryContract.SmsResultEntry.COLUMN_NAME_HOUROFDAY));
                contacts.add(new Contact(false, name, dayofweek, hourofday, phoneNumber));
            } while (c.moveToNext());
        c.close();

        for (Contact contact : contacts)
        {
            Calendar calendar = Calendar.getInstance();
            calendar.set(Calendar.DAY_OF_WEEK, contact.getNotificationDayOfWeek());
            calendar.set(Calendar.HOUR_OF_DAY, contact.getNotificationHourOfDay());
            calendar.set(Calendar.MINUTE, 0);

            // Create an intent that will be wrapped in PendingIntent
            Intent intent = new Intent(mainController.mainActivity, AlarmReceiver.class);
            intent.putExtra("CONTACT_NAME", CallLogAccessor
                    .getContactName(mainController.mainActivity, contact.getPhoneNumber()));
            intent.putExtra("NOTIFICATION_ID", count);
            intent.putExtra("TYPE", "SMS");
            intent.putExtra("PHONE_NUMBER", contact.getPhoneNumber());

            // Create the pending intent and wrap our intent
            PendingIntent pendingIntent =
                    PendingIntent.getBroadcast(mainController.mainActivity, count, intent, 0);

            // Testing notifications
            //            alarmManager.cancel(pendingIntent);
            //            alarmManager
            //                    .set(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + 5000, pendingIntent);
            //            break;

            if (System.currentTimeMillis() > calendar.getTimeInMillis())
            {
                alarmManager.setRepeating(AlarmManager.RTC_WAKEUP,
                        calendar.getTimeInMillis() + AlarmManager.INTERVAL_DAY * 7,
                        AlarmManager.INTERVAL_DAY * 7, pendingIntent);
                Log.d("Alarm", "Alarm time: " +
                        new Date(calendar.getTimeInMillis() + AlarmManager.INTERVAL_DAY * 7)
                                .toString());
            }
            else
            {
                alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(),
                        AlarmManager.INTERVAL_DAY * 7, pendingIntent);

                Log.d("Alarm", "Alarm time: " + new Date(calendar.getTimeInMillis()).toString());
            }
            pendingIntents.add(pendingIntent);
            count++;
        }
        // End of setting SMS notification timings
    }

    private final class ServiceHandler extends Handler
    {
        public ServiceHandler(Looper looper)
        {
            super(looper);
        }

        @Override
        public void handleMessage(Message msg)
        {
            int iDayOfWeek, iHourOfDay, processedCount = 0, total;
            db = mainController.callSmsHistoryDbHelper.getWritableDatabase();
            Calendar tempCalendar = Calendar.getInstance();

            // Update application's SMS history database
            mBuilder.setContentText("Sms history is being updated");
            updateSmsHistory();

            // Get updated SMS History database as ArrayList
            mBuilder.setContentText("Sms history is being fetched");
            ArrayList<HistoryItem> smsHistoryArrayList = getSmsHistoryArrayList();

            // Analyze the SMS History
            mBuilder.setContentText("Sms history is being analyzed");
            Analysis smsAnalysis = new Analysis();
            total = smsHistoryArrayList.size();
            processedCount = 0;
            for (HistoryItem historyItem : smsHistoryArrayList)
            {
                smsAnalysis.addIfNotExist(historyItem.phoneNumber);
                tempCalendar.setTime(historyItem.getDate());
                iDayOfWeek = tempCalendar.get(Calendar.DAY_OF_WEEK);
                iHourOfDay = tempCalendar.get((Calendar.HOUR_OF_DAY));
                smsAnalysis.increment(historyItem.phoneNumber, iDayOfWeek, iHourOfDay);
                mBuilder.setProgress(total, processedCount++, false);
                mNotifyManager.notify(id, mBuilder.build());
            }

            // Write SMS history analysis results to database
            mBuilder.setContentText("Saving SMS history analysis results");
            mainController.callSmsHistoryDbHelper.resetSmsResultTable(db);
            total = smsAnalysis.getList().size() * 7 * 24;
            processedCount = 0;
            for (Analysis.item it : smsAnalysis.getList())
            {
                for (int i = 1; i <= 7; i++)
                {
                    for (int j = 0; j <= 23; j++)
                    {
                        if (it.counts[i][j] == 0)
                        {
                            mBuilder.setProgress(total, processedCount++, false);
                            mNotifyManager.notify(id, mBuilder.build());
                            continue;
                        }
                        ContentValues values = new ContentValues();

                        values.put(CallSmsHistoryContract.SmsResultEntry.COLUMN_NAME_PHONE_NUMBER,
                                it.phoneNumber);
                        values.put(CallSmsHistoryContract.SmsResultEntry.COLUMN_NAME_DAYOFWEEK, i);
                        values.put(CallSmsHistoryContract.SmsResultEntry.COLUMN_NAME_HOUROFDAY, j);
                        values.put(CallSmsHistoryContract.SmsResultEntry.COLUMN_NAME_RATE,
                                it.counts[i][j]);
                        db.insert(CallSmsHistoryContract.SmsResultEntry.TABLE_NAME, null, values);
                        mBuilder.setProgress(total, processedCount++, false);
                        mNotifyManager.notify(id, mBuilder.build());
                    }
                }
            }

            // Update application's call history
            mBuilder.setContentText("Updating call history");
            updateCallHistory();

            // Get updated call history database as ArrayList
            mBuilder.setContentText("Fetching call history");
            ArrayList<HistoryItem> callHistoryArrayList = getCallHistoryArrayList();

            // Analyze the call History
            mBuilder.setContentText("Analyzing call history");
            Analysis callAnalysis = new Analysis();
            mainController.callSmsHistoryDbHelper.resetCallResultTable(db);
            total = callHistoryArrayList.size();
            processedCount = 0;
            for (HistoryItem c : callHistoryArrayList)
            {
                callAnalysis.addIfNotExist(c.phoneNumber);

                tempCalendar.setTime(c.getDate());
                iDayOfWeek = tempCalendar.get(Calendar.DAY_OF_WEEK);
                iHourOfDay = tempCalendar.get((Calendar.HOUR_OF_DAY));
                callAnalysis.increment(c.phoneNumber, iDayOfWeek, iHourOfDay);
                mBuilder.setProgress(total, processedCount++, false);
                mNotifyManager.notify(id, mBuilder.build());
            }

            // Write call history analysis results to database
            mBuilder.setContentText("Saving call history analysis results");
            total = callAnalysis.getList().size() * 7 * 24;
            processedCount = 0;
            for (Analysis.item it : callAnalysis.getList())
            {
                for (int i = 1; i <= 7; i++)
                {
                    for (int j = 0; j <= 23; j++)
                    {
                        if (it.counts[i][j] == 0)
                        {
                            mBuilder.setProgress(total, processedCount++, false);
                            mNotifyManager.notify(id, mBuilder.build());
                            continue;
                        }
                        ContentValues values = new ContentValues();

                        values.put(CallSmsHistoryContract.CallResultEntry.COLUMN_NAME_PHONE_NUMBER,
                                it.phoneNumber);
                        values.put(CallSmsHistoryContract.CallResultEntry.COLUMN_NAME_DAYOFWEEK, i);
                        values.put(CallSmsHistoryContract.CallResultEntry.COLUMN_NAME_HOUROFDAY, j);
                        values.put(CallSmsHistoryContract.CallResultEntry.COLUMN_NAME_RATE,
                                it.counts[i][j]);
                        db.insert(CallSmsHistoryContract.CallResultEntry.TABLE_NAME, null, values);
                        mBuilder.setProgress(total, processedCount++, false);
                        mNotifyManager.notify(id, mBuilder.build());
                    }
                }
            }

            // Update final result table
            mBuilder.setContentText("Combining analysis results");
            Analysis finalAnalysis = new Analysis();
            total = callAnalysis.getList().size() + smsAnalysis.getList().size();
            processedCount = 0;
            for (Analysis.item it : smsAnalysis.getList())
            {
                if (finalAnalysis.addIfNotExist(it.phoneNumber))
                    finalAnalysis.setCountsOfPhoneNumber(it.phoneNumber, it.counts);
                else
                    finalAnalysis.combineCountsOfPhoneNumber(it.phoneNumber, it.counts);
                mBuilder.setProgress(total, processedCount++, false);
                mNotifyManager.notify(id, mBuilder.build());
            }
            for (Analysis.item it : callAnalysis.getList())
            {
                if (finalAnalysis.addIfNotExist(it.phoneNumber))
                    finalAnalysis.setCountsOfPhoneNumber(it.phoneNumber, it.counts);
                else
                    finalAnalysis.combineCountsOfPhoneNumber(it.phoneNumber, it.counts);
                mBuilder.setProgress(total, processedCount++, false);
                mNotifyManager.notify(id, mBuilder.build());
            }

            mBuilder.setContentText("Saving final results to database");
            mainController.callSmsHistoryDbHelper.resetFinalResultTable(db);
            total = finalAnalysis.getList().size() * 7 * 24;
            processedCount = 0;
            for (Analysis.item it : finalAnalysis.getList())
            {
                for (int i = 1; i <= 7; i++)
                {
                    for (int j = 0; j <= 23; j++)
                    {
                        if (it.counts[i][j] == 0)
                        {
                            mBuilder.setProgress(total, processedCount++, false);
                            mNotifyManager.notify(id, mBuilder.build());
                            continue;
                        }
                        ContentValues values = new ContentValues();

                        values.put(CallSmsHistoryContract.FinalResultEntry.COLUMN_NAME_PHONE_NUMBER,
                                it.phoneNumber);
                        values.put(CallSmsHistoryContract.FinalResultEntry.COLUMN_NAME_DAYOFWEEK,
                                i);
                        values.put(CallSmsHistoryContract.FinalResultEntry.COLUMN_NAME_HOUROFDAY,
                                j);
                        values.put(CallSmsHistoryContract.FinalResultEntry.COLUMN_NAME_RATE,
                                it.counts[i][j]);
                        db.insert(CallSmsHistoryContract.FinalResultEntry.TABLE_NAME, null, values);
                        mBuilder.setProgress(total, processedCount++, false);
                        mNotifyManager.notify(id, mBuilder.build());
                    }
                }
            }

            mBuilder.setContentText("Setting notification timings").setProgress(0, 0, true);
            mNotifyManager.notify(id, mBuilder.build());
            setNotificationTimings();

            stopSelf();
        }
    }
}
