package atilimbitirme.smartphonebook.whotocall;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.preference.PreferenceManager;
import android.support.v7.app.NotificationCompat;

/**
 * onReceive method of this class is called by Android when a time has come to show a notification.
 * Created on 11.04.2016.
 */
public class AlarmReceiver extends BroadcastReceiver
{
    @Override
    public void onReceive(Context context, Intent intent)
    {
        SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(context);
        if (!sharedPref.getBoolean(context.getString(R.string.notifications_preference_key), true))
            return;

        int id = intent.getIntExtra("NOTIFICATION_ID", 0);
        String contactName = intent.getStringExtra("CONTACT_NAME");
        String notificationType = intent.getStringExtra("TYPE");
        NotificationManager mNotifyManager =
                (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(context);

        if (notificationType.equals("CALL"))
        {
            mBuilder.setContentTitle("Call " + contactName)
                    .setContentText("Most probable call time for " + contactName).
                    setSmallIcon(R.mipmap.ic_launcher);
            Intent callIntent = new Intent(Intent.ACTION_CALL);
            callIntent.setData(Uri.parse("tel:" + intent.getStringExtra("PHONE_NUMBER")));
            if (callIntent.resolveActivity(context.getPackageManager()) != null)
            {
                PendingIntent callPendingIntent =
                        PendingIntent.getActivity(context, id, callIntent, 0);
                mBuilder.addAction(R.drawable.ic_action_call, "Call", callPendingIntent);
            }
        }
        else if (notificationType.equals("SMS"))
        {
            mBuilder.setContentTitle("SMS " + contactName)
                    .setContentText("Most probable SMS time for " + contactName).
                    setSmallIcon(R.mipmap.ic_launcher);
            Intent smsIntent = new Intent(Intent.ACTION_SENDTO);
            smsIntent.setData(Uri.parse("smsto:" + intent.getStringExtra("PHONE_NUMBER")));
            if (smsIntent.resolveActivity(context.getPackageManager()) != null)
            {
                PendingIntent smsPendingIntent =
                        PendingIntent.getActivity(context, id, smsIntent, 0);
                mBuilder.addAction(R.drawable.ic_action_sms, "Send SMS", smsPendingIntent);
            }
        }
        mNotifyManager.notify(id, mBuilder.build());
    }
}
