package atilimbitirme.smartphonebook.whotocall;

import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.provider.ContactsContract;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import atilimbitirme.smartphonebook.whotocall.phonelogaccessors.CallLogAccessor;

/**
 * This is the array adapter for the main list in which ordered contacts are shown. {@link
 * #getView(int, View, ViewGroup)} method of this class is called by Android when a list item needs
 * to be displayed. By overriding it list items can be customized. For example, by this class photos
 * of the contacts can be fetched from phone book and be shown near the contact name. Created on
 * 24.04.2016.
 */
public class CustomListAdapter extends ArrayAdapter<String>
{
    public final List<String> objects;
    public List<ContactPhoto> contactPhotoList;
    Context context;
    LayoutInflater inflater;
    MainController mainController;

    public CustomListAdapter(Context context, int resource, int textViewResourceId,
                             List<String> objects, MainController mainController)
    {
        super(context, resource, textViewResourceId, objects);
        this.context = context;
        this.objects = objects;
        this.mainController = mainController;
        inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        contactPhotoList = new ArrayList<>();
        for (String s : objects)
        {
            String cName = CallLogAccessor.getContactName(context, s);

            if (cName.length() > 10)
            {
                cName.replace(" ", "\n");
            }
            contactPhotoList.add(new ContactPhoto(s, retrieveContactPhoto(s), cName));
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public View getView(final int position, View convertView, ViewGroup parent)
    {
        ViewHolder mViewHolder = null;

        if (convertView == null)
        {
            mViewHolder = new ViewHolder();
            convertView = inflater.inflate(R.layout.list_item, null, true);
            mViewHolder.textView = (TextView) convertView.findViewById(R.id.list_item_textview);
            mViewHolder.imageView = (ImageView) convertView.findViewById(R.id.list_item_image);
            mViewHolder.smsIcon = (ImageView) convertView.findViewById(R.id.list_item_message_icon);
            convertView.setTag(mViewHolder);
        }
        else
            mViewHolder = (ViewHolder) convertView.getTag();

        convertView.setOnTouchListener(new SwipeGestureListener(this, position, mViewHolder));
        convertView.setOnLongClickListener(new View.OnLongClickListener()
        {
            @Override
            public boolean onLongClick(View v)
            {
                mainController.mainActivity.openContextMenu(v);
                return true;
            }
        });

        if (objects.size() == 0)
            return convertView;

        if (objects.get(position).equals(contactPhotoList.get(position).phoneNumber))
        {
            mViewHolder.imageView.setImageBitmap(contactPhotoList.get(position).photo);
            mViewHolder.textView.setText(contactPhotoList.get(position).contactName);
        }
        else
        {
            for (ContactPhoto contactPhoto : contactPhotoList)
            {
                if (contactPhoto.phoneNumber.equals(objects.get(position)))
                {
                    mViewHolder.imageView.setImageBitmap(contactPhoto.photo);
                    mViewHolder.textView.setText(contactPhoto.contactName);
                    break;
                }
            }
        }
        if (position == 0)
            mViewHolder.textView.setTextSize(30);
        else if (position == 1)
            mViewHolder.textView.setTextSize(25);
        else if (position == 2)
            mViewHolder.textView.setTextSize(20);
        else
            mViewHolder.textView.setTextSize(15);

        return convertView;
    }

    private Bitmap retrieveContactPhoto(String number)
    {
        ContentResolver contentResolver = context.getContentResolver();
        String contactId = null;
        Uri uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI,
                Uri.encode(number));

        String[] projection =
                new String[]{ContactsContract.PhoneLookup.DISPLAY_NAME, ContactsContract.PhoneLookup._ID};

        Cursor cursor = contentResolver.query(uri, projection, null, null, null);
        Bitmap photo = BitmapFactory.decodeResource(context.getResources(), R.mipmap.ic_launcher);

        if (cursor != null)
        {
            while (cursor.moveToNext())
            {
                contactId = cursor.getString(
                        cursor.getColumnIndexOrThrow(ContactsContract.PhoneLookup._ID));
            }
            cursor.close();
        }

        if (contactId == null)
            return photo;


        try
        {
            InputStream inputStream = ContactsContract.Contacts
                    .openContactPhotoInputStream(context.getContentResolver(), ContentUris
                            .withAppendedId(ContactsContract.Contacts.CONTENT_URI,
                                    Long.valueOf(contactId)));

            if (inputStream != null)
            {
                photo = BitmapFactory.decodeStream(inputStream);
                inputStream.close();
            }

        } catch (IOException e)
        {
            e.printStackTrace();
        }
        return photo;
    }

    static class ViewHolder
    {
        public TextView textView;
        public ImageView icon;
        ImageView imageView;
        ImageView smsIcon;
    }

    public class ContactPhoto
    {
        public String phoneNumber, contactName;
        public Bitmap photo;

        public ContactPhoto(String phoneNumber, Bitmap photo, String contactName)
        {
            this.contactName = contactName;
            this.phoneNumber = phoneNumber;
            this.photo = photo;
        }

        public String getContactName()
        {
            return contactName;
        }
    }
}
