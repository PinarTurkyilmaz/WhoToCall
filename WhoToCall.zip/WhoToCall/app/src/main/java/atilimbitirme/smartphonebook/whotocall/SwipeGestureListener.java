package atilimbitirme.smartphonebook.whotocall;

import android.graphics.Color;
import android.view.MotionEvent;
import android.view.View;

/**
 * Created by 026 on 10.05.2016.
 */
class SwipeGestureListener implements View.OnTouchListener
{
    private static final int THRESHOLD = 200;
    private final int position;
    private final CustomListAdapter.ViewHolder finalMViewHolder;
    private CustomListAdapter customListAdapter;
    private int padding;
    private int initialx;
    private int currentx;

    public SwipeGestureListener(CustomListAdapter customListAdapter, int position,
                                CustomListAdapter.ViewHolder finalMViewHolder)
    {
        this.customListAdapter = customListAdapter;
        this.position = position;
        this.finalMViewHolder = finalMViewHolder;
        padding = 0;
        initialx = 0;
        currentx = 0;
    }

    public boolean onTouch(View v, MotionEvent event)
    {
        if (event.getAction() == MotionEvent.ACTION_DOWN)
        {
            padding = 0;
            initialx = (int) event.getX();
            currentx = (int) event.getX();
            return false;
        }
        if (event.getAction() == MotionEvent.ACTION_MOVE)
        {
            currentx = (int) event.getX();
            padding = currentx - initialx;
            if (padding < 15 && padding > -15)
                return false;
            if (padding > 15)
            {
                v.setBackgroundColor(0xFF0000FF); // Blue
                finalMViewHolder.textView.setText("CALLING...");
                finalMViewHolder.textView.setTextColor(Color.WHITE);
                finalMViewHolder.textView.setTextSize(20);
                finalMViewHolder.imageView.setImageResource(R.drawable.ic_action_call);
                finalMViewHolder.imageView.setVisibility(View.VISIBLE);
                finalMViewHolder.smsIcon.setVisibility(View.INVISIBLE);
            }
            else if (padding < 15)
            {
                finalMViewHolder.textView.setText("MESSAGE...");
                finalMViewHolder.textView.setTextColor(Color.WHITE);
                finalMViewHolder.textView.setTextSize(20);
                finalMViewHolder.smsIcon.setVisibility(View.VISIBLE);
                v.setBackgroundColor(0xFFFF0000);
                finalMViewHolder.imageView.setVisibility(View.INVISIBLE);
            }
        }
        if (event.getAction() == MotionEvent.ACTION_UP ||
                event.getAction() == MotionEvent.ACTION_CANCEL)
        {
            if (padding > THRESHOLD)
            {
                v.setBackgroundColor(0xFF0000FF); // Blue
                finalMViewHolder.icon.setImageResource(R.drawable.ic_action_call);
                padding = 0;
                try
                {
                    Thread.sleep(500);
                } catch (InterruptedException e)
                {
                    e.printStackTrace();
                }
                customListAdapter.mainController.callContact(position);
                //v.setBackgroundColor(0xffffffff);//yeşilden sonra beyaz yapmak için
            }
            padding = 0;
            initialx = 0;
            currentx = 0;
        }
        if (padding == 0)
        {
            v.setBackgroundColor(0x00000000); // Transparent
            finalMViewHolder.textView.setVisibility(View.VISIBLE);
            finalMViewHolder.textView
                    .setText(customListAdapter.contactPhotoList.get(position).getContactName());
            finalMViewHolder.textView.setTextColor(Color.DKGRAY);
            if (position == 0)
                finalMViewHolder.textView.setTextSize(30);
            else if (position == 1)
                finalMViewHolder.textView.setTextSize(25);
            else if (position == 2)
                finalMViewHolder.textView.setTextSize(20);
            else
                finalMViewHolder.textView.setTextSize(15);
            finalMViewHolder.imageView.setVisibility(View.VISIBLE);
            finalMViewHolder.imageView
                    .setImageBitmap(customListAdapter.contactPhotoList.get(position).photo);
            finalMViewHolder.smsIcon.setVisibility(View.INVISIBLE);
        }

        if (padding < -THRESHOLD)
        {
            try
            {
                Thread.sleep(500);
            } catch (InterruptedException e)
            {
                e.printStackTrace();
            }
            customListAdapter.mainController.sendSmsToContact(position);
            v.setBackgroundColor(0xFFFF0000); // Red
        }

        v.setPadding(padding, 0, 0, 0);

        return false;
    }
}
