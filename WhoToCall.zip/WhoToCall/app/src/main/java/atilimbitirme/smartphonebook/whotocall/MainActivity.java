package atilimbitirme.smartphonebook.whotocall;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

import atilimbitirme.smartphonebook.whotocall.phonelogaccessors.CallLogAccessor;

/**
 * Main activity class in which ordered contact list is shown.
 */
public class MainActivity extends AppCompatActivity
{
    static MainController mainController;
    public CustomListAdapter listViewAdapter;
    public ListView mainListView;
    CallLogAccessor callLogAccessor;
    Toolbar toolbar;
    SwipeRefreshLayout swipeRefreshLayout;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        mainController = MainController.getInstance(this);
        ArrayList<Contact> temp = new ArrayList<>();
        mainListView = (ListView) findViewById(R.id.list_view);
        registerForContextMenu(mainListView);
        callLogAccessor = new CallLogAccessor(this);
        mainController.getOrderedContacts();

        swipeRefreshLayout = (SwipeRefreshLayout) findViewById(R.id.swipe_refresh);
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener()
        {
            @Override
            public void onRefresh()
            {
                mainController.getOrderedContacts();
            }
        });
        // Check if notification preference is set
        if (!mainController.isNotificationsSet())
        {
            mainController.setNotifications(true);
        }
    }

    private void blockContact(int position)
    {
        mainController.blockContact(position);
        mainController.getOrderedContacts();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
        MenuItem menuItem = menu.findItem(R.id.set_notification_menu_item);
        assert menuItem != null;
        if (mainController.isNotificationsOn())
        {
            menuItem.setTitle(getString(R.string.turn_off_notification));
        }
        else
        {
            menuItem.setTitle(getString(R.string.turn_on_notification));
        }
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu)
    {
        menu.getItem(0).setEnabled(!mainController.isListBeingRefreshed());
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        // Handle item selection
        switch (item.getItemId())
        {
            case R.id.set_notification_menu_item:
                if (mainController.isNotificationsOn())
                {
                    mainController.setNotifications(false);
                    item.setTitle(R.string.turn_on_notification);
                }
                else
                {
                    mainController.setNotifications(true);
                    item.setTitle(R.string.turn_off_notification);
                }

                return true;

            case R.id.refresh_menu_item:
                this.refreshList(item);
                return true;

            case R.id.blocked_contacts_menu_item:
                showBlockedContacts();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenuInfo menuInfo)
    {
        super.onCreateContextMenu(menu, v, menuInfo);
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.context_menu, menu);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item)
    {
        AdapterView.AdapterContextMenuInfo info =
                (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        switch (item.getItemId())
        {
            case R.id.block_menu_item:
                blockContact(info.position);
                return true;
            default:
                return super.onContextItemSelected(item);
        }
    }

    private void showBlockedContacts()
    {
        Intent intent = new Intent(this, BlockedContactsActivity.class);
        startActivity(intent);
    }

    @Override
    protected void onResume()
    {
        super.onResume();
        mainController.getOrderedContacts();
    }

    /**
     * Called when the "Refresh" menu item is pushed. Shows a confirmation dialog.
     *
     * @param menuItem "Refresh" menu item. If user confirms refreshing list, it will be disabled.
     */
    public void refreshList(final MenuItem menuItem)
    {
        new AlertDialog.Builder(this).setTitle("Refresh List")
                .setMessage("Do you really want to refresh the list?")
                .setIcon(android.R.drawable.ic_dialog_alert)
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener()
                {
                    public void onClick(DialogInterface dialog, int whichButton)
                    {
                        menuItem.setEnabled(false);
                        mainController.refreshList();
                    }
                }).setNegativeButton(android.R.string.no, null).show();
    }

    public void showList(ArrayList<String> orderedContacts)
    {
        if (listViewAdapter != null)
        {
            listViewAdapter.clear();
            listViewAdapter.addAll(orderedContacts);
            listViewAdapter.notifyDataSetChanged();
        }
        else
        {
            listViewAdapter =
                    new CustomListAdapter(this, R.layout.list_item, R.id.list_item_textview,
                            orderedContacts, mainController);

            if (mainListView != null)
                mainListView.setAdapter(listViewAdapter);
        }
    }

    public void showContactList(ArrayList<Contact> contacts)
    {
        ArrayList<String> contactsAsString = new ArrayList<>();

        for (Contact c : contacts)
        {
            contactsAsString.add(c.getPhoneNumber());
        }
        showList(contactsAsString);
        swipeRefreshLayout.setRefreshing(false);
    }
}
