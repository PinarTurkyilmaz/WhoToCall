package atilimbitirme.smartphonebook.whotocall.asynctasks;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;

import java.util.ArrayList;
import java.util.Calendar;

import atilimbitirme.smartphonebook.whotocall.CallSmsHistoryContract;
import atilimbitirme.smartphonebook.whotocall.Contact;
import atilimbitirme.smartphonebook.whotocall.MainController;
import atilimbitirme.smartphonebook.whotocall.phonelogaccessors.CallLogAccessor;

/**
 * This class fetches the ordered contacts list from database asynchronously. It is used by {@link
 * atilimbitirme.smartphonebook.whotocall.MainController} for {@link
 * atilimbitirme.smartphonebook.whotocall.MainActivity MainActivity}. Created on 31.03.2016.
 */
public class FetchResultTableTask extends AsyncTask<Void, Integer, ArrayList<Contact>>
{
    SQLiteDatabase db;
    Calendar calendar;
    MainController mainController;

    public FetchResultTableTask(MainController mainController)
    {
        this.calendar = Calendar.getInstance();
        this.mainController = mainController;
    }

    @Override
    protected ArrayList<Contact> doInBackground(Void... params)
    {
        db = mainController.callSmsHistoryDbHelper.getReadableDatabase();

        String phoneNumber, name;
        ArrayList<Contact> resultArrayList = new ArrayList<>();

        // Get blocked contact list
        ArrayList<Contact> blockedContacts = new ArrayList<>();
        Cursor c =
                db.query(CallSmsHistoryContract.isBlockedEntry.TABLE_NAME, null, null, null, null,
                        null, null);

        c.moveToFirst();
        if (c.getCount() > 0)
            do
            {
                if (c.getString(
                        c.getColumnIndex(CallSmsHistoryContract.isBlockedEntry.COLUMN_NAME_BLOCKED))
                        .equals("t"))
                {
                    phoneNumber = c.getString(c.getColumnIndex(
                            CallSmsHistoryContract.CountEntry.COLUMN_NAME_PHONE_NUMBER));
                    blockedContacts.add(new Contact(true, CallLogAccessor
                            .getContactName(mainController.mainActivity, phoneNumber),
                            phoneNumber));
                }
            } while (c.moveToNext());

        c.close();
        // End of getting blocked contacts list

        int iCurrentDayOfWeek = this.calendar.get(Calendar.DAY_OF_WEEK);
        int iCurrentHourOfDay = this.calendar.get(Calendar.HOUR_OF_DAY);
        String selection = CallSmsHistoryContract.FinalResultEntry.COLUMN_NAME_DAYOFWEEK + " = " +
                iCurrentDayOfWeek + " AND " +
                CallSmsHistoryContract.FinalResultEntry.COLUMN_NAME_HOUROFDAY +
                " = " + iCurrentHourOfDay;
        String sortOrder = CallSmsHistoryContract.FinalResultEntry.COLUMN_NAME_RATE + " DESC";
        c = db.query(CallSmsHistoryContract.FinalResultEntry.TABLE_NAME,  // The table to query
                null,                               // The columns to return
                selection,                                // The columns for the WHERE clause
                null,                            // The values for the WHERE clause
                null,                                     // don't group the rows
                null,                                     // don't filter by row groups
                sortOrder                                 // The sort order
        );

        c.moveToFirst();
        if (c.getCount() > 0)
            do
            {
                phoneNumber = c.getString(c.getColumnIndex(
                        CallSmsHistoryContract.FinalResultEntry.COLUMN_NAME_PHONE_NUMBER));
                boolean isBlocked = false;
                for (Contact contact : blockedContacts)
                {
                    if (contact.getPhoneNumber().equals(phoneNumber))
                    {
                        isBlocked = true;
                        break;
                    }
                }
                name = CallLogAccessor.getContactName(mainController.mainActivity, phoneNumber);
                if (!isBlocked)
                    resultArrayList.add(new Contact(false, name, phoneNumber));
            } while (c.moveToNext());
        c.close();

        // Since the contacts whose rate is zero is not recorded to database,
        // the above code will not add them to the result list.

        // Below code add other contacts who are on the result table

        c = db.query(CallSmsHistoryContract.FinalResultEntry.TABLE_NAME, null, null, null,
                CallSmsHistoryContract.FinalResultEntry.COLUMN_NAME_PHONE_NUMBER, null, sortOrder);

        c.moveToFirst();
        if (c.getCount() > 0)
            do
            {
                phoneNumber = c.getString(c.getColumnIndex(
                        CallSmsHistoryContract.FinalResultEntry.COLUMN_NAME_PHONE_NUMBER));
                boolean isBlocked = false;
                for (Contact contact : blockedContacts)
                {
                    if (contact.getPhoneNumber().equals(phoneNumber))
                    {
                        isBlocked = true;
                        break;
                    }
                }
                name = CallLogAccessor.getContactName(mainController.mainActivity, phoneNumber);
                if (!isBlocked)
                {
                    boolean found = false;
                    for (Contact contact : resultArrayList)
                    {
                        if (contact.getPhoneNumber().equals(phoneNumber))
                        {
                            found = true;
                            break;
                        }
                    }
                    if (!found)
                        resultArrayList.add(new Contact(false, name, phoneNumber));
                }
            } while (c.moveToNext());
        c.close();

        return resultArrayList;
    }

    @Override
    protected void onPostExecute(ArrayList<Contact> contacts)
    {
        mainController.setOrderedContacts(contacts);
    }
}
