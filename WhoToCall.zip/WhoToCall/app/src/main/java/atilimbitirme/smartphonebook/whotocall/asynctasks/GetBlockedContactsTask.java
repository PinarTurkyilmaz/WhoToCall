package atilimbitirme.smartphonebook.whotocall.asynctasks;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;

import java.util.ArrayList;

import atilimbitirme.smartphonebook.whotocall.CallSmsHistoryContract;
import atilimbitirme.smartphonebook.whotocall.CallSmsHistoryDbHelper;
import atilimbitirme.smartphonebook.whotocall.Contact;
import atilimbitirme.smartphonebook.whotocall.MainController;
import atilimbitirme.smartphonebook.whotocall.phonelogaccessors.CallLogAccessor;

/**
 * This class fetches the blocked contacts list from database asynchronously. It is used by {@link
 * atilimbitirme.smartphonebook.whotocall.MainController} for {@link
 * atilimbitirme.smartphonebook.whotocall.BlockedContactsActivity BlockedContactsActivity}. Created
 * on 10.04.2016.
 */
public class GetBlockedContactsTask extends AsyncTask<Void, Void, ArrayList<Contact>>
{
    MainController mainController;
    CallSmsHistoryDbHelper callSmsHistoryDbHelper;

    public GetBlockedContactsTask(CallSmsHistoryDbHelper callSmsHistoryDbHelper,
                                  MainController mainController)
    {
        this.callSmsHistoryDbHelper = callSmsHistoryDbHelper;
        this.mainController = mainController;
    }

    @Override
    protected ArrayList<Contact> doInBackground(Void... params)
    {
        SQLiteDatabase db = callSmsHistoryDbHelper.getReadableDatabase();
        Cursor c =
                db.query(CallSmsHistoryContract.isBlockedEntry.TABLE_NAME, null, null, null, null,
                        null, null);
        ArrayList<Contact> resultArrayList = new ArrayList<>();

        String phoneNumber, blocked;
        c.moveToFirst();
        if (c.getCount() > 0)
            do
            {
                blocked = c.getString(c.getColumnIndex(
                        CallSmsHistoryContract.isBlockedEntry.COLUMN_NAME_BLOCKED));
                if (blocked.equals("t"))
                {
                    phoneNumber = c.getString(c.getColumnIndex(
                            CallSmsHistoryContract.CountEntry.COLUMN_NAME_PHONE_NUMBER));
                    resultArrayList.add(new Contact(true, CallLogAccessor
                            .getContactName(mainController.mainActivity, phoneNumber),
                            phoneNumber));
                }
            } while (c.moveToNext());

        c.close();
        return resultArrayList;
    }

    @Override
    protected void onPostExecute(ArrayList<Contact> contacts)
    {
        mainController.setBlockedContacts(contacts);
    }
}
