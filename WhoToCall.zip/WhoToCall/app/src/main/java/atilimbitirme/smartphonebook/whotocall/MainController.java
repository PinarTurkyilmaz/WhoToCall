package atilimbitirme.smartphonebook.whotocall;

import android.app.ActivityManager;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.preference.PreferenceManager;
import android.support.v7.app.NotificationCompat;
import android.widget.Toast;

import java.util.ArrayList;

import atilimbitirme.smartphonebook.whotocall.asynctasks.FetchResultTableTask;
import atilimbitirme.smartphonebook.whotocall.asynctasks.GetBlockedContactsTask;

/**
 * This is the controller class. This class provides coordination between user interface and data
 * and analysis operations. Created on 02.04.2016.
 */
public class MainController
{
    static MainController uniqueInstance;
    public MainActivity mainActivity;
    public BlockedContactsActivity blockedContactsActivity;
    public CallSmsHistoryDbHelper callSmsHistoryDbHelper;
    public ArrayList<String> orderedStringContacts;
    public ArrayList<Contact> orderedContacts;
    private ArrayList<Contact> blockedContacts;

    public MainController(BlockedContactsActivity blockedContactsActivity)
    {
        this.blockedContactsActivity = blockedContactsActivity;
    }

    private MainController(MainActivity mainActivity)
    {
        this.mainActivity = mainActivity;
        callSmsHistoryDbHelper = new CallSmsHistoryDbHelper(mainActivity);
        orderedContacts = new ArrayList<>();
    }

    // Singleton pattern is used
    public static MainController getInstance(MainActivity mainActivity)
    {
        if (uniqueInstance == null)
        {
            uniqueInstance = new MainController(mainActivity);
        }
        uniqueInstance.setMainActivity(mainActivity);
        return uniqueInstance;
    }

    public static MainController getInstance(BlockedContactsActivity blockedContactsActivity)
    {
        if (uniqueInstance == null)
        {
            uniqueInstance = new MainController(blockedContactsActivity);
        }
        uniqueInstance.blockedContactsActivity = blockedContactsActivity;
        return uniqueInstance;
    }

    public void setBlockedContacts(ArrayList<Contact> blockedContacts)
    {
        this.blockedContacts = blockedContacts;
        blockedContactsActivity.showBlockedContactsList(blockedContacts);
    }

    public void getBlockedContacts()
    {
        new GetBlockedContactsTask(callSmsHistoryDbHelper, this).execute();
    }

    public void setMainActivity(MainActivity mainActivity)
    {
        this.mainActivity = mainActivity;
    }

    public void refreshList()
    {
        Intent resultIntent = new Intent(mainActivity, MainActivity.class);
        int id = 1;
        PendingIntent resultPendingIntent =
                PendingIntent.getActivity(mainActivity, 0, resultIntent, 0);
        NotificationManager mNotifyManager =
                (NotificationManager) mainActivity.getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(mainActivity);
        mBuilder.setContentTitle("List Refresh")
                .setContentText("New records are being collected and analysed").
                setSmallIcon(R.mipmap.ic_launcher).setContentIntent(resultPendingIntent);
        mBuilder.setProgress(100, 0, false);
        mNotifyManager.notify(id, mBuilder.build());
        RefreshService refreshService = new RefreshService(this, mNotifyManager, mBuilder, id);
        Intent intent = new Intent(mainActivity, RefreshService.class);
        mainActivity.startService(intent);
    }

    public void getOrderedContacts()
    {
        new FetchResultTableTask(this).execute();
    }

    public void setOrderedContacts(ArrayList<Contact> contacts)
    {
        this.orderedContacts = contacts;
        mainActivity.showContactList(contacts);
    }

    public void blockContact(int position)
    {
        String phoneNumber = orderedContacts.get(position).getPhoneNumber();

        ContentValues cv = new ContentValues();
        cv.put(CallSmsHistoryContract.isBlockedEntry.COLUMN_NAME_PHONE_NUMBER, phoneNumber);
        cv.put(CallSmsHistoryContract.isBlockedEntry.COLUMN_NAME_BLOCKED, "t");

        SQLiteDatabase db = callSmsHistoryDbHelper.getWritableDatabase();

        /*
        Firstly try to insert phone number and block status to table.
        This is done to prevent the update statement to fail.
         */
        db.insert(CallSmsHistoryContract.isBlockedEntry.TABLE_NAME, null, cv);

        /*
        Since the phone number is the primary key of the table insert statement may fail.
        That's why the update statement is called to make sure the bloced status of the phone
        number is saved.
         */
        db.update(CallSmsHistoryContract.isBlockedEntry.TABLE_NAME, cv,
                CallSmsHistoryContract.isBlockedEntry.COLUMN_NAME_PHONE_NUMBER + "=?",
                new String[]{phoneNumber});

        Toast.makeText(mainActivity, orderedContacts.get(position).getFullName() + " " +
                mainActivity.getString(R.string.block_message), Toast.LENGTH_LONG).show();
    }

    public void sendSmsToContact(int index)
    {
        Intent intent = new Intent(Intent.ACTION_SENDTO);
        intent.setData(Uri.parse("smsto:" + orderedContacts.get(index)
                .getPhoneNumber()));  // This ensures only SMS apps respond
        if (intent.resolveActivity(mainActivity.getPackageManager()) != null)
        {
            mainActivity.startActivity(intent);
        }
    }

    public void callContact(int index)
    {
        Intent intent = new Intent(Intent.ACTION_CALL);
        intent.setData(Uri.parse("tel:" + orderedContacts.get(index).getPhoneNumber()));
        if (intent.resolveActivity(mainActivity.getPackageManager()) != null)
        {
            mainActivity.startActivity(intent);
        }
    }

    public void unblockContact(int index)
    {
        String phoneNumber = blockedContacts.get(index).getPhoneNumber();

        ContentValues cv = new ContentValues();
        cv.put(CallSmsHistoryContract.isBlockedEntry.COLUMN_NAME_BLOCKED, "f");

        SQLiteDatabase db = callSmsHistoryDbHelper.getWritableDatabase();

        int rows = db.update(CallSmsHistoryContract.isBlockedEntry.TABLE_NAME, cv,
                CallSmsHistoryContract.isBlockedEntry.COLUMN_NAME_PHONE_NUMBER + "=?",
                new String[]{phoneNumber});
        Toast.makeText(blockedContactsActivity, blockedContacts.get(index).getFullName() + " " +
                blockedContactsActivity.getString(R.string.unblock_message), Toast.LENGTH_LONG)
                .show();
    }

    public void setNotifications(boolean isOn)
    {
        SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(mainActivity);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putBoolean(mainActivity.getString(R.string.notifications_preference_key), isOn);
        editor.apply();
        if (isOn)
            Toast.makeText(mainActivity, mainActivity.getString(R.string.notifications_on_message),
                    Toast.LENGTH_LONG).show();
        else
            Toast.makeText(mainActivity, mainActivity.getString(R.string.notifications_off_message),
                    Toast.LENGTH_LONG).show();
    }

    public boolean isNotificationsSet()
    {
        SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(mainActivity);
        return sharedPref.contains(mainActivity.getString(R.string.notifications_preference_key));
    }

    public boolean isNotificationsOn()
    {
        SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(mainActivity);
        if (BuildConfig.DEBUG &&
                !sharedPref.contains(mainActivity.getString(R.string.notifications_preference_key)))
            throw new AssertionError();
        return sharedPref
                .getBoolean(mainActivity.getString(R.string.notifications_preference_key), true);
    }

    public boolean isListBeingRefreshed()
    {
        ActivityManager manager =
                (ActivityManager) mainActivity.getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager
                .getRunningServices(Integer.MAX_VALUE))
        {
            if (RefreshService.class.getName().equals(service.service.getClassName()))
            {
                return true;
            }
        }
        return false;
    }
}
