package atilimbitirme.smartphonebook.whotocall;

import android.provider.BaseColumns;

/**
 * In this class, table and column names of the local SQLite is assigned to variables. The reason
 * for this is that when a table or column name changes, it will be enough to change it here only.
 * Created on 21.03.2016.
 */
public class CallSmsHistoryContract
{
    // To prevent someone from accidentally instantiating the contract class,
    // give it an empty constructor.
    public CallSmsHistoryContract()
    {
    }

    /* Inner class that defines the table contents */

    // Table that holds accumulated call history
    public static abstract class CallEntry implements BaseColumns
    {
        public static final String TABLE_NAME = "call";
        public static final String COLUMN_NAME_PHONE_NUMBER = "phonenumber";
        public static final String COLUMN_NAME_DATETIME = "datetime";
        public static final String COLUMN_NAME_DURATION = "duration";
    }

    // Table that holds accumulated sent SMS message history
    public static abstract class SMSEntry implements BaseColumns
    {
        public static final String TABLE_NAME = "sms";
        public static final String COLUMN_NAME_PHONE_NUMBER = "phonenumber";
        public static final String COLUMN_NAME_DATETIME = "datetime";
    }

    // Table that holds block status of contacts
    public static abstract class isBlockedEntry implements BaseColumns
    {
        public static final String TABLE_NAME = "isblocked";
        public static final String COLUMN_NAME_PHONE_NUMBER = "phonenumber";
        public static final String COLUMN_NAME_BLOCKED = "blocked";
    }

    // Table that holds result of analysis
    public static abstract class CountEntry implements BaseColumns
    {
        public static final String TABLE_NAME = "count";
        public static final String COLUMN_NAME_PHONE_NUMBER = "phonenumber";
        public static final String COLUMN_NAME_DAYOFWEEK = "dayofweek";
        public static final String COLUMN_NAME_HOUROFDAY = "hourofday";
        public static final String COLUMN_NAME_COUNT = "count";
    }

    // Table that holds result of analysis of call history
    public static abstract class CallResultEntry implements BaseColumns
    {
        public static final String TABLE_NAME = "callresult";
        public static final String COLUMN_NAME_PHONE_NUMBER = "phonenumber";
        public static final String COLUMN_NAME_DAYOFWEEK = "dayofweek";
        public static final String COLUMN_NAME_HOUROFDAY = "hourofday";
        public static final String COLUMN_NAME_RATE = "rate";

    }

    // Table that holds result of analysis of SMS history
    public static abstract class SmsResultEntry implements BaseColumns
    {
        public static final String TABLE_NAME = "smsresult";
        public static final String COLUMN_NAME_PHONE_NUMBER = "phonenumber";
        public static final String COLUMN_NAME_DAYOFWEEK = "dayofweek";
        public static final String COLUMN_NAME_HOUROFDAY = "hourofday";
        public static final String COLUMN_NAME_RATE = "rate";
    }

    // Table that holds result of analysis of both call and SMS history
    public static abstract class FinalResultEntry implements BaseColumns
    {
        public static final String TABLE_NAME = "finalresult";
        public static final String COLUMN_NAME_PHONE_NUMBER = "phonenumber";
        public static final String COLUMN_NAME_DAYOFWEEK = "dayofweek";
        public static final String COLUMN_NAME_HOUROFDAY = "hourofday";
        public static final String COLUMN_NAME_RATE = "rate";
    }
}
