package atilimbitirme.smartphonebook.whotocall.phonelogaccessors;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.ContactsContract;

import atilimbitirme.smartphonebook.whotocall.CallSmsHistoryDbHelper;

/**
 * Created by 026 on 21.03.2016.
 */
public class CallLogAccessor
{
    static CallSmsHistoryDbHelper callSmsHistoryDbHelper;
    static Context context;

    public CallLogAccessor(Context context)
    {
        CallLogAccessor.context = context;
        callSmsHistoryDbHelper = new CallSmsHistoryDbHelper(context);
    }

    public static String getContactName(Context context, String phoneNumber)
    {
        ContentResolver cr = context.getContentResolver();
        Uri uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI,
                Uri.encode(phoneNumber));
        Cursor cursor =
                cr.query(uri, new String[]{ContactsContract.PhoneLookup.DISPLAY_NAME}, null, null,
                        null);
        if (cursor == null)
        {
            return phoneNumber;
        }
        String contactName = phoneNumber;
        if (cursor.moveToFirst())
        {
            contactName = cursor.getString(
                    cursor.getColumnIndex(ContactsContract.PhoneLookup.DISPLAY_NAME));
        }

        if (!cursor.isClosed())
        {
            cursor.close();
        }

        return contactName;
    }
}
